from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
import pyodbc
import pickle
import os
import numpy as np
import joblib

app = Flask(__name__)
CORS(app, supports_credentials=True)

# 📁 Déterminer le chemin absolu
base_path = os.path.dirname(__file__)

# 📦 Charger les modèles
with open(os.path.join(base_path, "model_iforest.pkl"), "rb") as f:
    iso_forest = pickle.load(f)

with open(os.path.join(base_path, "model_revenue_rf.pkl"), "rb") as f:
    revenue_model, revenue_features = pickle.load(f)

with open(os.path.join(base_path, "model_retard_rf.pkl"), "rb") as f:
    retard_model, retard_features = pickle.load(f)

with open(os.path.join(base_path, "clustering_litiges.pkl"), "rb") as f:
    clustering_bundle = pickle.load(f)

clustering_encoder = clustering_bundle["encoder"]
clustering_pca = clustering_bundle["pca"]
clustering_model = clustering_bundle["model"]

# 🔄 Chargement et traitement des produits
def load_and_process_data():
    conn = pyodbc.connect(
        "DRIVER={SQL Server};"
        "SERVER=DESKTOP-9MQ1CAL;"
        "DATABASE=DW_FINANCE;"
        "Trusted_Connection=yes;"
    )
    df = pd.read_sql("SELECT * FROM Fact_ReviewProduct", conn)
    conn.close()

    df["ReviewScore"] = pd.to_numeric(df["ReviewScore"], errors="coerce")
    df["ReviewCount"] = pd.to_numeric(df["ReviewCount"], errors="coerce")
    df["Price"] = df["Price"].str.replace(',', '.').astype(float)
    df.dropna(subset=["ReviewScore", "ReviewCount", "Price"], inplace=True)

    X = df[["Price", "ReviewScore", "ReviewCount"]]
    df["IForest"] = iso_forest.predict(X)
    df["Score_IForest"] = iso_forest.decision_function(X)
    df["AnomalyConsensus"] = (df["IForest"] == -1).astype(int)

    return df

# 🧪 Anomalies produits
@app.route("/api/all-products", methods=["GET"])
def get_all_products():
    df = load_and_process_data()
    return df.to_json(orient="records")

@app.route("/api/anomalies", methods=["GET"])
def get_anomalies():
    df = load_and_process_data()
    anomalies = df[df["AnomalyConsensus"] == 1]
    return anomalies.to_json(orient="records")

@app.route("/api/check-product", methods=["POST"])
def check_product():
    try:
        data = request.json
        input_df = pd.DataFrame([[ 
            float(data.get("Price")),
            float(data.get("ReviewScore")),
            float(data.get("ReviewCount"))
        ]], columns=["Price", "ReviewScore", "ReviewCount"])

        prediction = iso_forest.predict(input_df)[0]
        score = iso_forest.decision_function(input_df)[0]

        return jsonify({
            "Anomaly": int(prediction == -1),
            "Score": score
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# 💰 Prédiction du Revenu
@app.route("/api/predict-revenue", methods=["POST"])
def predict_revenue():
    try:
        input_df = pd.DataFrame([request.json])[revenue_features]
        prediction = revenue_model.predict(input_df)[0]
        return jsonify({"prediction": round(prediction, 2)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# 🔁 Mise à jour Revenu SQL
@app.route("/api/update-revenue-column", methods=["POST"])
def update_revenue_column():
    try:
        conn = pyodbc.connect(
            "DRIVER={SQL Server};"
            "SERVER=DESKTOP-9MQ1CAL;"
            "DATABASE=DW_FINANCE;"
            "Trusted_Connection=yes;"
        )
        cursor = conn.cursor()

        query = """
        WITH RankedFinance AS (
            SELECT *, ROW_NUMBER() OVER (PARTITION BY year ORDER BY NEWID()) AS rn
            FROM Fact_Finance
        )
        SELECT * FROM RankedFinance WHERE rn = 1 ORDER BY year;
        """
        df = pd.read_sql(query, conn).drop(columns=["rn"])

        df_list = []
        np.random.seed(42)
        for _ in range(20):
            copie = df.copy()
            for col in copie.select_dtypes(include=[np.number]).columns:
                if col != "year":
                    bruit = np.random.normal(0, 0.05, len(copie))
                    copie[col] = copie[col] * (1 + bruit)
            df_list.append(copie)

        df_aug = pd.concat(df_list, ignore_index=True)
        X = df_aug.drop(columns=["Revenu", "GrandLivreIDFK", "StatementIDFK", "RevenuPrévu_NextYear"], errors="ignore")

        predictions = {}
        for annee in range(2015, 2025):
            ligne = pd.DataFrame([X.drop(columns=["year"]).mean()])
            ligne["year"] = annee + 1
            ligne = ligne[revenue_features]
            revenu = revenue_model.predict(ligne)[0]
            predictions[annee] = round(revenu, 2)

        for annee, revenu in predictions.items():
            cursor.execute("""
                UPDATE Fact_Finance SET RevenuPrévu_NextYear = ? WHERE year = ?
            """, revenu, annee)

        conn.commit()
        cursor.close()

        return jsonify({"message": "✅ Mise à jour RevenuPrévu_NextYear réussie."})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# ⏱️ Prédiction de Retard de Paiement
@app.route("/api/check-delay", methods=["POST", "OPTIONS"])
def check_delay():
    if request.method == "OPTIONS":
        return jsonify({"status": "OK"}), 200

    try:
        input_df = pd.DataFrame([request.json])[retard_features]
        prediction = retard_model.predict(input_df)[0]
        proba = retard_model.predict_proba(input_df)[0][1]
        return jsonify({
            "Prediction": int(prediction),
            "Proba_Late": round(proba, 4)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# 🚨 Clustering Litiges
@app.route("/api/cluster-litige", methods=["POST"])
def cluster_litige():
    try:
        data = request.json
        input_df = pd.DataFrame([{
            "Status": data.get("Status"),
            "Reason": data.get("Reason")
        }])

        encoded_input = clustering_encoder.transform(input_df[["Status", "Reason"]])
        pca_input = clustering_pca.transform(encoded_input)
        cluster_pred = clustering_model.predict(encoded_input)[0]

        return jsonify({
            "ClusterPrediction": int(cluster_pred)
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400
@app.route("/api/forecast-errors", methods=["GET"])
def forecast_errors():
    try:
        conn = pyodbc.connect(
            "DRIVER={SQL Server};"
            "SERVER=DESKTOP-9MQ1CAL;"
            "DATABASE=DW_FINANCE;"
            "Trusted_Connection=yes;"
        )
        df_supply = pd.read_sql("SELECT InvoiceID, InvoiceDate, PaymentDate FROM Fact_Supply", conn)
        df_date = pd.read_sql("SELECT * FROM DIM_Date", conn)
        conn.close()

        # Jointures sur dates
        for col in ["InvoiceDate", "PaymentDate"]:
            df_supply = df_supply.merge(
                df_date.rename(columns={"DateKey": col, "Date": f"{col}_Real"}),
                on=col,
                how="left"
            )

        df_supply["InvoiceDate"] = pd.to_datetime(df_supply["InvoiceDate_Real"])
        df_supply["PaymentDate"] = pd.to_datetime(df_supply["PaymentDate_Real"])
        df_supply["DaysToPay"] = (df_supply["PaymentDate"] - df_supply["InvoiceDate"]).dt.days
        df_supply["IsError"] = (df_supply["DaysToPay"] < 0).astype(int)

        df_ts = df_supply.groupby("InvoiceDate")["IsError"].sum().asfreq("D").fillna(0)
        train = df_ts[:-30]
        test = df_ts[-30:]

        from statsmodels.tsa.seasonal import STL
        stl = STL(train, period=7).fit()
        pred_stl = stl.trend[-30:].fillna(method='bfill')

        # Formater pour Angular
        forecast = [{"date": str(date.date()), "prediction": float(value)} for date, value in zip(test.index, pred_stl)]

        return jsonify({
            "forecast": forecast
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# 🏠 Home
@app.route("/api", methods=["GET"])
def home():
    return "Bienvenue sur l'API Flask - Angular disponible sur http://localhost:4200"

if __name__ == "__main__":
    app.run(debug=True)
